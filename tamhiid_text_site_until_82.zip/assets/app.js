async function load(){
  const res = await fetch('assets/data.json');
  const data = await res.json();

  const toc = document.getElementById('toc');
  const q = document.getElementById('q');
  const clearBtn = document.getElementById('clearBtn');
  const content = document.getElementById('content');
  const meta = document.getElementById('meta');

  meta.textContent = `${data.meta.note} — الأقسام: ${data.meta.sections_count}`;

  let currentId = 1;

  function snippet(txt){
    const t = (txt || '').trim().replace(/\s+/g,' ');
    if(!t) return '';
    return t.length > 90 ? t.slice(0,90) + '…' : t;
  }

  function buildTOC(filtered){
    toc.innerHTML = '';
    filtered.forEach(sec=>{
      const a = document.createElement('a');
      a.href = '#s' + sec.id;
      a.dataset.id = sec.id;
      a.innerHTML = `<strong>${sec.id}. ${sec.title}</strong><small>${snippet(sec.content)}</small>`;
      a.addEventListener('click', (e)=>{
        e.preventDefault();
        setSection(sec.id);
      });
      toc.appendChild(a);
    });
  }

  function setActive(id){
    [...toc.querySelectorAll('a')].forEach(a=>{
      a.classList.toggle('active', Number(a.dataset.id)===id);
    });
  }

  function setSection(id){
    const sec = data.sections.find(s=>s.id===id);
    if(!sec) return;
    currentId = id;
    content.innerHTML = `
      <h1 class="hTitle">${sec.id}. ${sec.title}</h1>
      <div class="tools">
        <button id="copyBtn">نسخ النص</button>
        <button id="prevBtn" ${id===1?'disabled':''}>السابق</button>
        <button id="nextBtn" ${id===data.sections.length?'disabled':''}>التالي</button>
      </div>
      <hr/>
      <div class="p">${escapeHtml(sec.content)}</div>
    `;
    setActive(id);
    window.location.hash = 's' + id;

    document.getElementById('copyBtn').onclick = async ()=>{
      await navigator.clipboard.writeText(`${sec.title}\n\n${sec.content}`);
      toast('تم النسخ ✅');
    };
    const prev = document.getElementById('prevBtn');
    const next = document.getElementById('nextBtn');
    if(prev) prev.onclick = ()=> setSection(Math.max(1, id-1));
    if(next) next.onclick = ()=> setSection(Math.min(data.sections.length, id+1));
  }

  function escapeHtml(str){
    return (str||'')
      .replaceAll('&','&amp;')
      .replaceAll('<','&lt;')
      .replaceAll('>','&gt;');
  }

  function toast(msg){
    const d = document.createElement('div');
    d.textContent = msg;
    d.style.position='fixed';
    d.style.bottom='16px';
    d.style.left='16px';
    d.style.background='rgba(19,21,27,.95)';
    d.style.border='1px solid #2a2e39';
    d.style.padding='10px 12px';
    d.style.borderRadius='14px';
    d.style.color='#e8e8ea';
    d.style.zIndex='9999';
    document.body.appendChild(d);
    setTimeout(()=>{ d.remove(); }, 1200);
  }

  function applySearch(){
    const term = q.value.trim();
    if(!term){
      buildTOC(data.sections);
      setSection(currentId);
      return;
    }
    const t = term;
    const filtered = data.sections.filter(s =>
      (s.title && s.title.includes(t)) || (s.content && s.content.includes(t))
    );
    buildTOC(filtered.length ? filtered : data.sections);
    if(filtered.length) setSection(filtered[0].id);
  }

  q.addEventListener('input', applySearch);
  clearBtn.addEventListener('click', ()=>{ q.value=''; applySearch(); });

  buildTOC(data.sections);

  const m = (window.location.hash||'').match(/^#s(\d+)$/);
  if(m) currentId = Math.max(1, Math.min(data.sections.length, Number(m[1])));
  setSection(currentId);
  window.addEventListener('hashchange', ()=>{
    const m2 = (window.location.hash||'').match(/^#s(\d+)$/);
    if(m2) setSection(Number(m2[1]));
  });
}

load().catch(err=>{
  console.error(err);
  document.getElementById('content').textContent = 'حدث خطأ في التحميل.';
});
